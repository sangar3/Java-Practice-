/*
* @author Santiago Garcia II
* <p> Savaings.Java
* <p> Project 6
* <p> this java class file represents an actual savings account keep a minimum balance. 

*/
public class Savings extends Account
{
	static final double MIN_AMOUNT =100; //minimum  amount you can hold in the account
	
	public Savings()
	{
		super();
	
	}
	
	public Savings(String N)
	{
		super(N);
	}
	
	@Override
	public void withdraw(double amt) throws InsufficientFundsException
	{
		if (_balance -  getMinimum() >= amt)	
		{
			_balance = _balance - amt;	//withdrawing money 
			
		}
		
		else 
		{
			if(_link == null) //checked for any linked accounts 
			{
				throw new  InsufficientFundsException("Overdraft with no linked account!!");
			}
			if(_balance -getMinimum() +_link._balance <amt )
			{
				throw new InsufficientFundsException("Not enough funds in accounts!!");
			}
			amt = amt - (_balance -getMinimum());
			_balance = getMinimum();
			_link.withdraw(amt);
		}
			
	}
	
	public double getMinimum()	//gets the the Minimum value
	{
		return 100;
	}
	
	
	
	
	
	
	
	
	
	@Override
    public boolean link(Account linkAcct)
    {
    	if (linkAcct == null) return false;
    	
		if (linkAcct instanceof Savings) return false;
		
		return super.link(linkAcct);
    }
	
    @Override
    public boolean equals(Object obj)
    {
    	if (obj == null) return false;
    	
    	if (!(obj instanceof Savings)) return false;

    	return super.equals(obj);
    }
	
    @Override
    public String toString()
    {
    	return "Savings " + super.toString();
    }
}

