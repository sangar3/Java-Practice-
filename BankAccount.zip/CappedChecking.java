/*
* @author Santiago Garcia II
* <p> CappedChecking.Java
* <p> Project 6
* <p> this java class is a checking account and it disallows balance over a certain value
*/
public class CappedChecking extends Checking 
{
	static final double MAX_AMOUNT = 10000; // maximum amount of money you can hold in your bank 
	
	public CappedChecking()
	{
		super();
	}
	
	public CappedChecking(String N)	//overload constructor
	{
		super(N);
	}
	
	public void deposit(double amt) throws LinkAccountException
	{
		if(_balance +amt <= MAX_AMOUNT)
		{
			_balance +=amt;
		}
		else
		{
			if(_link==null) throw new LinkAccountException("Overflowed, No Linked Account!");
			{
				amt-= (MAX_AMOUNT -_balance);
				_balance = MAX_AMOUNT;
				_link.despoit(amt);
			}
		}
	}
    @Override
    public boolean equals(Object obj)
    {
    	if (obj == null) return false;
    	
    	if (!(obj instanceof CappedChecking)) return false;

    	return super.equals(obj);
    }
	
    @Override
    public String toString()
    {
    	return "Capped-Checking " + super.toString();
    }
}
