/*
* @author Santiago Garcia II
* <p> Checking.Java
* <p> Project 6
* <p> this java class is a checking account that doesn't contain a  minimum value. 

*/
public class Checking extends Account
{
	
	public Checking()
	{
		super();
	}
	public Checking(String N) // overload constructor
	{
		super(N);
	}

	@Override
    public boolean link(Account linkAcct)		//links this account to another account 
    {
    	if (linkAcct == null) return false;
    	
		if (linkAcct instanceof Checking) return false;
		
		return super.link(linkAcct);
    }
	
    @Override
    public boolean equals(Object obj)
    {
    	if (obj == null) return false;
    	
    	if (!(obj instanceof Checking)) return false;

    	return super.equals(obj);
    }
	
    @Override
    public String toString()
    {
    	return "Checking " + super.toString();
    }
}
