/*
* @author Santiago Garcia II
* <p> Bank.Java
* <p> Project 6
* <p> this java class represents a real life bank for many different accounts 
*/
import java.util.ArrayList;
public class Bank
{
	private ArrayList <Account> accounts = new ArrayList<Account>();
	
	public boolean AddAccount(Account acct)	//this method adds an account to this bank 
	{
		if(acct ==null)
		{
			return false;
		}
		if (accounts.contains(acct))
		{
			return false;
		}
		
		accounts.add(acct);
		return true;
	}
	
	public ArrayList<Account>getFiltered()	//this method would filter out any account that is not acceptable
	{
		ArrayList<Account>FilteredList = new ArrayList<Account>();
		
		for(Account acct: accounts)
		{
			if(acct.accept()) 
			{
				FilteredList.add(acct);
			}
			
			
		}
		return FilteredList;
	}
	
	public int size()	//this method gets the actual size of the bank depending on the # of accounts 
	{
		return accounts.size();
	}
}
