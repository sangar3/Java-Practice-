/*
* @author Santiago Garcia II
* <p> Filterable.Java
* <p> Project 6
* <p> this java class 
*/
public interface Filterable
{
	public boolean accept();
}
