/*
* @author Santiago Garcia II
* <p> Account.Java
* <p> Project 6
* <p> this java class file represents real life accounts that has implemented operations like deposit, withdraw,etc.
*/
public class Account implements Filterable
{
    protected double _balance;	//balance in account 
    protected String _name;
   
    
    public double getBalance()	
    { 
    	return _balance;
    }
    
   
  
    
    public String getName() 
    	{ 
    	
    	return _name; 
    	}
    
    protected Account _link;
    public Account getLink() { return _link; }

	public Account()
	{
		this("");
	}
	
	public Account(String name)
	{
		_name = name;
		_balance =0; 
		_link =null;
		
	}
    

    public boolean link(Account linkAcct)
    {
		if(linkAcct == null) 
		{
			return false;
		}
		
		if(this == linkAcct)
		{
			return true;
		}
		
		unlink();
		
		return true;
		
    }
    
    public void despoit(double amt) throws LinkAccountException //adds the money to the account
    {
    	_balance += amt;
    }

  
    public void withdraw(double amt) throws InsufficientFundsException //removes money from account 
    {
   
    	if (_balance >= amt)	 //check if there is enough money in this account to withdraw
    		{
    		_balance -= amt;
    		}

    	
    	else // When the account doesn't have enough
    	{
   
    		if (_link == null)
    			throw new InsufficientFundsException("Overdraft with no linked account");

    		//check if there is enough money in this account and its linked account combined
    		if (_balance + _link._balance < amt)
    			throw new InsufficientFundsException("Not enough funds in accounts");

    		
    		amt -= _balance;
    		_balance = 0;
    		_link.withdraw(amt);
    	}
    }
    
    //
    // Unlink the accounts in BOTH directions
    //
    public void unlink()
    {
		if(_link == null)
		{
			return;
		}
		_link._link =null;
		_link =null;
		
    }
    
    public double getMinimum()	
    {
    	return 0;
    }
    
    public boolean accept()

    {
    	return true;
    }
    
    
    
   
    @Override
    public boolean equals(Object obj)
    {
    	if (obj == null) return false;
    	
    	if (!(obj instanceof Account)) return false;

    	Account that = (Account)obj;
    	
    	if (Math.abs(_balance - that._balance) > 0.001) return false; 

    	if (!_name.equals(that._name)) return false;
    	
    	if (_link != that._link) return false;
    	
    	return this == obj;
    }
    
    @Override
    public String toString()
    {
    	String retS = "";
    	
    	retS += "account: " + _name + "\n";
    	retS += "\tBalance: " + _balance + "\n";
    	retS += "\tLink account name: " + _link._name;
    	
    	return retS;
    }
}
