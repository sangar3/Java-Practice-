Overview
Construct a hierarchy of classes representing savings and checking accounts as well as a means to �filter�
account objects.


Account Classes
My solution will consist of 4 account classes as described below. It is your responsibility to define the
exact relationship among those classes and translate that relationship into source code structure. There is a
correct structure; the skeleton must be modified to reflect the correct relationships.
Account � represents a general account with basic operations such as deposit, withdraw, etc.
 Savings � represents a savings account that must maintain a minimum balance.
 Checking � represents a checking account that has no minimum balance (this means a zero
balance).
 CappedChecking � represents a checking account that disallows a balance above a particular
maximum value. 
