/***************************************************************
<Santiago Garcia II>
< RecursiveAlgorithm .java>
<Project 3>
<.>
***************************************************************/
public class RecursiveAlgorithm 
{
	public static int Fibonacci(int x)	//Recursion method 
	{
		if(x <=1 )
		{
			return x;
		}
		
	return Fibonacci(x-1) + Fibonacci(x-2);	//the time complexity 
	}
	
	
	
	
	
	public static void main(String[] args)
	{
		int n = 9;	//testing Recursion method 
		
		System.out.println("the number "+ n +" has a Fibonacci number of "+ Fibonacci(n));

	}

}
