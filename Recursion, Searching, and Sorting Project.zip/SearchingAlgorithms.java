/***************************************************************
<Santiago Garcia II>
< SearchingAlgorithms.java>
<Project 3>
<.>
***************************************************************/

import java.util.Arrays;

public class SearchingAlgorithms
{
	public static <T> boolean linearSearch(T[] data, T target)
	{
		return linearSearch(data, 0, data.length - 1, target);
	}
	static int linearcount =0;
	public static <T> boolean linearSearch(T[] data, int min, int max, T target) 
	{
		
		boolean found = false;
	
		int index = min;
		while (!found && index <= max) 
		{
			
			found = data[index].equals(target);
			linearcount++;
			index++;
			

		}
		
		return found;
	}

	public static <T extends Comparable<T>> boolean binarySearch(T[] data, T target)
	{
		return binarySearch(data, 0, data.length - 1, target);
	}
	
	static int binarycount =0;
	
	public static <T extends Comparable<T>> boolean binarySearch(T[] data, int min, int max, T target) 
	{
		
		boolean found = false;

		int midpoint = (min + max) / 2;

		int compareResult = data[midpoint].compareTo(target);

		if (compareResult == 0)
		{
			found = true;
		}
		else if (compareResult > 0) 
		{
			if (min <= midpoint - 1) 
			{
				found = binarySearch(data, min, midpoint - 1, target);
				
			}

		} 
		
		else if (midpoint + 1 <= max)
		{
			binarycount++;
			found = binarySearch(data, midpoint + 1, max, target);
			
		}
		
		return found;
	}

	public static void main(String[] args) 
	{
		Integer[] pool = { 5 , 8 , 10, 13, 15, 20, 22, 26, 30, 31, 34,40,45,60};	// the list of numbers that are being searched 
		
		Integer binarytarget = 8;
		boolean binaryfound;
		binaryfound = SearchingAlgorithms.binarySearch(pool,binarytarget);
		boolean  binarydata_set_is_ordered = true;
		
		if( binarydata_set_is_ordered)	//checking if data is ordered 
		{
			binaryfound = SearchingAlgorithms.binarySearch(pool, binarytarget);
		}
		else
		{
			binaryfound = SearchingAlgorithms.binarySearch(pool, binarytarget);
		}
		
		if(binaryfound)
		{
			System.out.println("The number was found in with a BinarySearch with " + (binarycount-1) +  " comparsions " );	//this prints when the number is found and the number of comparisons with BinarySearch 
		}
		else 
		{
			System.out.println("The number was not found in a BinarySearch number pool"); //this prints when the number is not  found 
		}
		
		
		Integer[] pool2 = { 5 , 8 , 10, 13, 15, 20, 22, 26, 30, 31, 34,40,45,60}; // the list of numbers that are being searched 
		
		Integer target = 8;
		boolean linearfound;
		linearfound = SearchingAlgorithms.linearSearch(pool2,target);
		boolean  lineardata_set_is_ordered = true;
		
		if( lineardata_set_is_ordered) //checking if data is ordered 
		{
			linearfound = SearchingAlgorithms.linearSearch(pool2, target);
		}
		else
		{
			linearfound = SearchingAlgorithms.linearSearch(pool2, target);
		}
		
		if(linearfound)
		{
			System.out.println("The number was found in with a LinearSearch with " + (linearcount/2)+  " comparsions " );	//this prints when the number is found and the number of comparisons with LinearSearch 
		}
		else 
		{
			System.out.println("The number was not found in a LinearSearch number pool"); //this prints when the number is not  found 
		}
	}
	
	
}
