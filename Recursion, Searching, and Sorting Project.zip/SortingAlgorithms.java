/***************************************************************
<Santiago Garcia II>
< SortingAlgorithms.java>
<Project 3>
<.>
***************************************************************/
import java.util.Arrays;

public class SortingAlgorithms 
{
	static int bubblecompares =0;
	public static <T extends Comparable<T>> void bubblesort(T[] data, int min, int max) // this sorts the stated values using BubbleSort
	{
		for (int position = data.length -1 ; position >=0; --position)
		{
			for(int scan =0; scan < position;++scan )
			{
				bubblecompares ++; // a count as a compare
				if(data[scan].compareTo(data[scan+1]) >0)
				{
					
					swap(data, scan, scan +1); 
				}
			}
		}
	}
	
	static int selectioncompares =0;
	private static <T extends Comparable<T>> void selectionSort( T[] data )	// this sorts the stated values using selectionSort
	{
		for( int index = 0; index< data.length -1; ++index)
		{
			int min = index;
			
			for(int scan = index +1; scan < data.length; ++scan)
			{
				
				if(data[scan].compareTo(data[min]) <0)
				{
				
					min = scan;
				}
			}
			selectioncompares++; // a count as a compare
			if(index != min)
			{
				swap(data, index, min);
			}
		}
	}
	
	
	
	private static <T> void swap(T[] data, int index1, int index2 )
	{
		T temp = data[index1];
		
		data[index1] = data[index2];
		
		data[index2] = temp;
	}
	
	static int insertioncompares =0;
	public static <T extends Comparable<T>> void insertionSort(T[] data) 	// this sorts the stated values using insertionSort
	{
		for (int index = 1; index < data.length; index++) 
		{
			T key = data[index];

			int position = index;
			while (position > 0 && data[position - 1].compareTo(key) > 0)
			{
				data[position] = data[position - 1];
				insertioncompares++; // a count as a compare
				position--;
			}
			data[position] = key;
		}
	}

	
	
	public static <T extends Comparable<T>> void quicksort(T[] data)
	{
		quicksort(data, 0, data.length-1);
	}
	
	static int quickcompares =0;
	
	public static <T extends Comparable<T>> void quicksort(T[] data, int min, int max)
	{
		if( min< max)
		{	
		quickcompares++; // a count as a compare
		int indexOfPartition = partition(data, min, max);
		quicksort(data, min, indexOfPartition -1);
		quicksort(data, indexOfPartition + 1, max);
		}
	}
	
	public static <T extends Comparable<T>> int partition(T[] data, int min, int max) 
	{
		int middle =  (min + max)/2;
		T partitionElement = data[middle];
		
		
		swap(data, middle, min);
		int left = min ;
		int right = max;
		while( left < right)
		{
			while(left < right && data[left].compareTo(partitionElement) <=0)
			{
				++left;
			}
			while(data[right].compareTo(partitionElement) > 0)
			{
				--right;
			}
			
			if (left < right )
			{
				swap(data, left, right);
			}
		}
		swap(data, left, right);
		return right;
	}
	
	public static <T extends Comparable<T>> void mergeSort(T[] data)
	{
		mergeSort(data, 0, data.length-1);
	}
	
	static int mergecompares =0;
	private static <T extends Comparable<T>> void mergeSort (T[] data, int min, int max)		// this sorts the stated values using mergeSort
	{
		if(min <max)
		{
			int mid =(min +max)/2;
			mergeSort(data, min, mid);
			mergeSort(data, min +1, max);
			merge(data, min, mid, max);
			
		}
	}
	
	private static <T extends Comparable<T>> void merge(T[]data, int first, int mid, int last)
	{
		T[] temp = (T[]) ( new Comparable[data.length]);
		
		int first1 = first, last1 = mid; 
		int first2 = mid+1, last2 = last; 
		int index = first1;
		
		
		while( first1<= last1 && first2 <=2)
		{
			mergecompares++; // a count as a compare
			if( data[first1].compareTo(data[first2])<0 )
			{
				temp[index] = data[first1];
				
				first1++;
				
			}
			else 
			{
				temp[index] = data[first2];
				first2++;
			}
			index++;
		}
		while(first1 <= last1)
		{
			temp[index] = data[first1];
			first1++;
			index++;
		}
		
		while(first2 <= last2)
		{
			temp[index] = data[first2];
			first2++;
			index++;
		}
		
		for( index = first; index <= last; index++)
		{
			data[index] = temp[index];
		}
	}
	
	public static void main(String[] args)
	{
		Integer[] unsorteddata = {67, 19, 17, 83, 47, 87, 31, 97, 19, 43, 71, 59, 37, 11 };
		
		//declaring each sorting method to sort the data
		SortingAlgorithms.quicksort(unsorteddata);	
		SortingAlgorithms.insertionSort(unsorteddata);
		SortingAlgorithms.bubblesort(unsorteddata, 11, 97);
		SortingAlgorithms.selectionSort(unsorteddata);
		SortingAlgorithms.mergeSort(unsorteddata);
			
		
		System.out.println("Algorithm            # of Comparisons" );	//printing out each comparisons for each sorting method 
		System.out.println("-------------------------------------");
		System.out.println("Bubble sort "  + 	bubblecompares);
		System.out.println("Selection sort " + 	selectioncompares);
		System.out.println("Merge sort " + 	mergecompares);
		System.out.println("Insertion sort " + 	insertioncompares);
		System.out.println("Quick sort "  + 		quickcompares);
		
		
	}
	
	
	
}
